# DynComm-R-package
Dynamic Network Communities Detection and Generation - R Package 

This package has the following features:

- Dynamic Louvain Algorithm
- TILES Community Detection in Dynamic Networks
- RDyn generation module for dynamic networks
- Community Density Optimization

TODO:

- Addition of more Dynamic community Detection Algorithms,
with the use of the developed modules
